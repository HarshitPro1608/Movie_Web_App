package dev.harshit.movies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesApplicationTests {

	@Test
	void contextLoads() {
	}

}
